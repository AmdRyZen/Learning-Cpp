#![allow(unused_must_use)]
#[macro_use]
extern crate rbatis;

use std::sync::Arc;
use actix_web::{get, post, web, App, HttpResponse, HttpServer, Responder};
use actix_web::web::Data;

use rbatis::crud::{CRUD};
use rbatis::{Page, PageRequest};
use rbatis::rbatis::Rbatis;


#[get("/")]
async fn hello() -> impl Responder {
    HttpResponse::Ok().body("Hello world!")
}

#[post("/echo")]
async fn echo(req_body: String) -> impl Responder {
    HttpResponse::Ok().body(req_body)
}

async fn manual_hello() -> impl Responder {
    HttpResponse::Ok().body("Hey there!")
}

#[crud_table]
#[derive(Clone, Debug)]
pub struct TMediaScreenshot {
    pub id: Option<i32>,
    pub name: Option<String>,
    pub pull_url: Option<String>,
    pub server_name: Option<String>,
    pub status: Option<i32>,
    pub created_at: Option<rbatis::DateTimeNative>,
}

impl Default for TMediaScreenshot {
    fn default() -> Self {
        TMediaScreenshot {
            id: None,
            name: None,
            pull_url: None,
            server_name: None,
            status: None,
            created_at: None,
        }
    }
}

//mysql driver url
pub const MYSQL_URL: &'static str = "mysql://root:@localhost:3306/pirate_tv";

async fn index(rb: web::Data<Arc<Rbatis>>) -> impl Responder {
    let v = rb.fetch_list::<TMediaScreenshot>().await.unwrap();

    let req = PageRequest::new(1, 20);//分页请求，页码，条数
    let wraper= rb.new_wrapper()
        .eq("status",1);
    let data: Page<TMediaScreenshot> = rb.fetch_page_by_wrapper( wraper,  &req).await.unwrap();
    println!("{}", serde_json::to_string(&data).unwrap());
    HttpResponse::Ok().body(serde_json::json!(data).to_string())
}


#[actix_web::main]
async fn main() -> std::io::Result<()> {
    // CROSS_COMPILE=aarch64-apple-darwin- cargo build --release --target aarch64-apple-darwin
    //cargo build --release --target=aarch64-apple-darwin
    //SDKROOT=$(xcrun -sdk macosx11.1 --show-sdk-path) MACOSX_DEPLOYMENT_TARGET=$(xcrun -sdk macosx11.1 --show-sdk-platform-version) cargo build --release --target=aarch64-apple-darwin

    //log
    fast_log::init_log("requests.log", 1000, log::Level::Info, None, true);
    //init rbatis . also you can use  lazy_static! { static ref RB: Rbatis = Rbatis::new(); } replace this
    log::info!("linking database...");
    let rb = Rbatis::new();
    rb.link(MYSQL_URL).await.expect("rbatis link database fail");
    let rb = Arc::new(rb);
    log::info!("linking database successful!");

    HttpServer::new(move || {
        App::new()
            .app_data(Data::new(rb.to_owned()))
            .service(hello)
            .service(echo)
            .route("/hey", web::get().to(manual_hello))
            .route("/get", web::get().to(index))
    })
        .bind("127.0.0.1:9090")?
        .workers(12)
        .run()
        .await
}